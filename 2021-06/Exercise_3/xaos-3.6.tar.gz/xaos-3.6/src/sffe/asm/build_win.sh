#!/bin/bash
nasm -f coff cmplx.asm -ocmplx.o
# Not used anymore because ../Makefile already contains this compilation.
