/*#define IDI_XAOS_ICON                       128
   #define IDI_SMALL_ICON                      129 */
/*#define IDOK 0 */
